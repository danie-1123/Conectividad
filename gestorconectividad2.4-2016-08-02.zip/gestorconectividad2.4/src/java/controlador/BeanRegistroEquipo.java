
package controlador;


public class BeanRegistroEquipo {
    
    
    private String placa;
    private String marca;
    private String modelo;
    private String disco;
    private String memoria;
    private String procesador;

    public BeanRegistroEquipo(String placa, String marca, String modelo, String disco, String memoria, String procesador) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.disco = disco;
        this.memoria = memoria;
        this.procesador = procesador;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getDisco() {
        return disco;
    }

    public void setDisco(String disco) {
        this.disco = disco;
    }

    public String getMemoria() {
        return memoria;
    }

    public void setMemoria(String memoria) {
        this.memoria = memoria;
    }

    public String getProcesador() {
        return procesador;
    }

    public void setProcesador(String procesador) {
        this.procesador = procesador;
    }
    
    
    
}
