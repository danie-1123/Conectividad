
package controlador;


public class BeanReservaEquipo {
    
          private String documento;
          private String placa;
          private String fecha_inicio;
          private String fecha_fin;
          private String observaciones;
          private String respuesta;

    public BeanReservaEquipo(String documento, String placa, String fecha_inicio, String fecha_fin, String observaciones, String respuesta) {
        this.documento = documento;
        this.placa = placa;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
        this.observaciones = observaciones;
        this.respuesta = respuesta;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public String getFecha_fin() {
        return fecha_fin;
    }

    public void setFecha_fin(String fecha_fin) {
        this.fecha_fin = fecha_fin;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }
          
          
          
          
    
}
