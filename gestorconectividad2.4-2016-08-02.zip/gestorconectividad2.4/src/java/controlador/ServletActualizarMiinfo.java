/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Dao;

/**
 *
 * @author Andres
 */
@WebServlet(name = "ServletActualizarMiinfo", urlPatterns = {"/ServletActualizarMiinfo"})
public class ServletActualizarMiinfo extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        boolean editarDatos = false;
        boolean editarcontrasena = false;
            
            if (request.getParameter("editarinfo")!=null) {
                editarDatos = true;
                
            }
            if (request.getParameter("editarcontrasena")!=null) {
                editarcontrasena = true;
            
        }
            if (editarDatos) {
            try {
                String nombre = request.getParameter("txtnombre");
                String primerApellido = request.getParameter("txtprimerapellido");
                String segundoApellido = request.getParameter("txtsegundoapellido");
                String documento = request.getParameter("txtcedula");
                String telefono = request.getParameter("txttelefono");
                String celular = request.getParameter("txtcelular");
                String correo = request.getParameter("txtcorreo");
                String codigo = request.getParameter("txtcodigo");
                String contrasena = request.getParameter("txtcontrasena");
                String rol = request.getParameter("txtrol");
                
                BeanUsuario miUsuario = new BeanUsuario(contrasena, documento, nombre, primerApellido, segundoApellido, correo, rol, telefono, celular, codigo);
                
                Dao miDao=new Dao();
                
                miDao.actualizarUsuario(miUsuario);        
                //response.sendRedirect("ConfiguracionCuenta.jsp");
                String mensaje = "Datos Actualizados";
                request.setAttribute("mensaje", mensaje);
                request.getRequestDispatcher("ConfiguracionCuenta.jsp").forward(request, response);
            } catch (SQLException ex) {
                Logger.getLogger(ServletActualizarMiinfo.class.getName()).log(Level.SEVERE, null, ex);
            }
           
          }
            /*******************************************************************/
            if (editarcontrasena) {
                
            try {
                String contrasena = request.getParameter("txtContrasena");
                String documento = request.getParameter("documento");
                
                Dao miDao = new Dao();
                if (miDao.cambiarContrasena(contrasena, documento)) {
                String mensaje1 = "Cambio exitoso";
                request.setAttribute("mensaje1", mensaje1);
                request.getRequestDispatcher("ConfiguracionCuenta.jsp").forward(request, response);
                }
                        
                        } catch (SQLException ex) {
                Logger.getLogger(ServletActualizarMiinfo.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        
        
        
        
        
        
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            
//            
//            
//        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
