
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ClassConex {
    
    private String driver;
    private String url;
    private String user;
    private String pass;
    public Connection cn;

    public ClassConex() throws SQLException {

        try {
            driver = "com.mysql.jdbc.Driver";
            url = "jdbc:mysql://localhost/gestor_conectividad";
            user = "root";
            pass = "";
            
            Class.forName(driver);
            cn = DriverManager.getConnection(url, user, pass);
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClassConex.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
}
