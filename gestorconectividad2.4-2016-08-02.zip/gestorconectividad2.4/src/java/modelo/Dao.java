package modelo;

import controlador.BeanPrestamo;
import controlador.BeanPrestamoComponentes;
import controlador.BeanRegistroComponente;
import controlador.BeanRegistroEquipo;
import controlador.BeanReservaComponente;
import controlador.BeanReservaComponente2;
import controlador.BeanReservaEquipo;
import controlador.BeanReservaEquipo2;
import controlador.BeanUsuario;
import java.sql.JDBCType;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Dao extends ClassConex {

    public Dao() throws SQLException {
        super();
    }

    public void cerrarConexion() {

        try {
            cn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean registrarUsuario(BeanUsuario miUsuario) {

        try {

            String documento = miUsuario.getDocumento();
            String nombre = miUsuario.getNombre();
            String primerApellido = miUsuario.getPrimerApellido();
            String segundoApellido = miUsuario.getSegundoApellido();
            String correo = miUsuario.getCorreo();
            String rol = miUsuario.getRol();
            String telefono = miUsuario.getTelefono();
            String celular = miUsuario.getCelular();
            String codigo = miUsuario.getCodigo();

            String update = "insert into usuarios values('" + 0 + "','" + documento + "','" + documento + "','" + nombre + "','" + primerApellido + "','" + segundoApellido + "','" + correo + "','" + rol + "','" + telefono + "','" + celular + "','" + codigo + "');";
            Statement st = cn.createStatement();
            st.executeUpdate(update);
            System.out.println(update);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public boolean registrarPrestamo(BeanPrestamo miPrestamo) {

        try {

            String documento = miPrestamo.getDocumento();
            String placa = miPrestamo.getPlaca();
            String fecha_inicio = miPrestamo.getFecha_inicio();
            String fecha_fin = miPrestamo.getFecha_inicio();
            String observacion = miPrestamo.getObservacion();

            String update = "insert into prestamo_equipos values('" + 0 + "','" + documento + "','" + placa + "','" + fecha_inicio + "','" + fecha_fin + "','" + observacion + "'); ";
            Statement st = cn.createStatement();
            st.executeUpdate(update);
            System.out.println(update);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public boolean registrarPrestamoComponente(BeanPrestamoComponentes miBean) {

        try {

            String documento = miBean.getDocumento();
            String tipo = miBean.getDocumento();
            String placa = miBean.getPlaca();
            String fecha_inicio = miBean.getFecha_inicio();
            String fecha_fin = miBean.getFecha_inicio();
            String observacion = miBean.getObservaciones();

            String update = "insert into prestamo_componentes values('" + 0 + "','" + documento + "','" + tipo + "','" + placa + "','" + fecha_inicio + "','" + fecha_fin + "','" + observacion + "'); ";
            Statement st = cn.createStatement();
            st.executeUpdate(update);
            System.out.println(update);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public boolean registrarEquipo(BeanRegistroEquipo miEquipo) {

        try {

            String placa = miEquipo.getPlaca();
            String marca = miEquipo.getMarca();
            String modelo = miEquipo.getModelo();
            String disco = miEquipo.getDisco();
            String memoria = miEquipo.getMemoria();
            String procesador = miEquipo.getProcesador();

            String update = "insert into equipos values('" + 0 + "','" + placa + "','" + marca + "','" + modelo + "','" + disco + "','" + memoria + "','" + procesador + "');";
            Statement st = cn.createStatement();
            st.executeUpdate(update);
            System.out.println(update);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public boolean registrarComponente(BeanRegistroComponente miComponente) {

        try {

            String tipo = miComponente.getTipo();
            String placa = miComponente.getPlaca();
            String marca = miComponente.getMarca();
            String modelo = miComponente.getModelo();
            String color = miComponente.getColor();

            String update = "insert into componentes values('" + 0 + "','" + tipo + "','" + placa + "','" + marca + "','" + modelo + "','" + color + "');";
            Statement st = cn.createStatement();
            st.executeUpdate(update);
            System.out.println(update);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public boolean registrarReservaEquipo(BeanReservaEquipo miReserva) {

        try {

            String documento = miReserva.getDocumento();
            String placa = miReserva.getPlaca();
            String fecha_inicio = miReserva.getFecha_inicio();
            String fecha_fin = miReserva.getFecha_fin();
            String observaciones = miReserva.getObservaciones();
            String respuesta = miReserva.getRespuesta();

            String update = "insert into reserva_equipos values('" + 0 + "','" + documento + "','" + placa + "','" + fecha_inicio + "','" + fecha_fin + "','" + observaciones + "','" + respuesta + "');";
            Statement st = cn.createStatement();
            st.executeUpdate(update);
            System.out.println(update);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public ResultSet consultarUsuario(BeanUsuario miUsuario) {

        try {
            String correo = miUsuario.getCorreo();
            String contrasena = miUsuario.getContrasena();

            String query = "select * from usuarios where correo='" + correo + "' and contrasena='" + contrasena + "'; ";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(query);

            if (rs.next()) {
                return rs;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public ResultSet consultarCorreo(BeanUsuario miUsuario) {

        try {
            String correo = miUsuario.getCorreo();
            String query = "select * from usuarios where correo='" + correo + "'; ";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(query);

            if (rs.next()) {
                return rs;

            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public BeanUsuario consultarDocumento(BeanUsuario miUsuario) {

        try {
            String documento1 = miUsuario.getDocumento();
            String query = "select * from usuarios where documento='" + documento1 + "'; ";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(query);

            if (rs.next()) {
                String documento = rs.getString(3);
                String nombre = rs.getString(4);
                String primerApellido = rs.getString(5);
                String segundoApellido = rs.getString(6);
                String correo = rs.getString(7);
                String rol = rs.getString(8);
                String telefono = rs.getString(9);
                String celular = rs.getString(10);

                BeanUsuario usuario = new BeanUsuario(null, documento, nombre, primerApellido, segundoApellido, correo, rol, telefono, celular, null);
                return usuario;

            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public ResultSet consultarCodigo(BeanUsuario miUsuario) {

        try {
            String codigo = miUsuario.getCodigo();

            String query = "select * from usuarios where codigo='" + codigo + "'; ";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(query);

            if (rs.next()) {
                return rs;

            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public boolean actualizarContrasena(BeanUsuario miBean) {
        try {
            String contrasena = miBean.getContrasena();
            String codigo = miBean.getCodigo();
            String update = "update usuarios set contrasena='" + contrasena + "' where codigo='" + codigo + "'; ";
            Statement st = cn.createStatement();
            st.executeUpdate(update);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public BeanUsuario mostrarInformacion(String documento) {
        try {
            BeanUsuario misDatos = null;

            String sql = "select * from usuarios where documento = '" + documento + "';";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {

                misDatos = new BeanUsuario(
                        rs.getString("contrasena"),
                        rs.getString("documento"),
                        rs.getString("nombre"),
                        rs.getString("primer_apellido"),
                        rs.getString("segundo_apellido"),
                        rs.getString("correo"),
                        rs.getString("rol"),
                        rs.getString("telefono"),
                        rs.getString("celular"),
                        rs.getString("codigo"));

                return misDatos;

            }

        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;

    }

    public boolean actualizarUsuario(BeanUsuario Usuario) {

        try {
            String nombre = Usuario.getNombre();
            String primerApellido = Usuario.getPrimerApellido();
            String segundoApellido = Usuario.getSegundoApellido();
            String documento = Usuario.getDocumento();
            String contrasena = Usuario.getContrasena();
            String correo = Usuario.getCorreo();
            String rol = Usuario.getRol();
            String telefono = Usuario.getTelefono();
            String celular = Usuario.getCelular();
            String codigo = Usuario.getCodigo();

            String actualizar = "update usuarios set nombre = '" + nombre + "', primer_apellido = '" + primerApellido + "',"
                    + "segundo_apellido = '" + segundoApellido + "',"
                    + "documento = '" + documento + "', contrasena = '" + contrasena + "',"
                    + "correo = '" + correo + "', rol = '" + rol + "', telefono = '" + telefono + "',"
                    + "celular = '" + celular + "', codigo = '" + codigo + "'"
                    + "where nombre = '" + nombre + "';";

            Statement st = cn.createStatement();
            st.executeUpdate(actualizar);
            return true;

        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public boolean elminarUsuario(String documento) {

        try {
            String eliminar = "delete from usuarios where documento = '" + documento + "';";
            Statement st = cn.createStatement();
            st.executeUpdate(eliminar);
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public ResultSet listarUsuarios(int pg, int numreg) {
        ResultSet rs = null;
        try {
            String listar = "Select * from usuarios order by id limit " + pg + " , " + numreg + "; ";
            Statement st = cn.createStatement();
            rs = st.executeQuery(listar);

        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;

    }

    public ResultSet listarEquipos(int pg, int numreg) {
        try {
            ResultSet rs = null;

            String listarEquipos = "Select * from equipos order by id limit " + pg + " , " + numreg + ";";
            Statement st = cn.createStatement();
            rs = st.executeQuery(listarEquipos);

            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public BeanRegistroEquipo mostrarEquipos(String placa) {

        try {
            BeanRegistroEquipo miEquipo = null;

            String consultarEquipo = "Select * from equipos where placa = '" + placa + "';";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(consultarEquipo);

            if (rs.next()) {
                miEquipo = new BeanRegistroEquipo(
                        rs.getString("placa"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getString("disco"),
                        rs.getString("memoria"),
                        rs.getString("procesador"));

                return miEquipo;

            }
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public boolean actualizarEquipo(BeanRegistroEquipo miEquipo) {

        try {
            String placa = miEquipo.getPlaca();
            String marca = miEquipo.getMarca();
            String modelo = miEquipo.getModelo();
            String disco = miEquipo.getDisco();
            String memoria = miEquipo.getMemoria();
            String procesador = miEquipo.getProcesador();

            String actualizarEquipo = "update equipos set placa = '" + placa + "',"
                    + "marca = '" + marca + "', modelo='" + modelo + "',"
                    + "disco = '" + disco + "', memoria= '" + memoria + "',"
                    + "procesador = '" + procesador + "' where placa = '" + placa + "';";
            Statement st = cn.createStatement();
            st.executeUpdate(actualizarEquipo);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public boolean eliminarEquipo(String placa) {

        try {
            String eliminar = "Delete from equipos where placa='" + placa + "'";
            Statement st = cn.createStatement();
            st.executeUpdate(eliminar);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public ResultSet listarComponentes(int pg, int numreg) {
        try {
            ResultSet rs = null;

            String listarComponentes = "select * from componentes order by id limit " + pg + " , " + numreg + " ;";
            Statement st = cn.createStatement();
            rs = st.executeQuery(listarComponentes);
            return rs;

        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public BeanRegistroComponente mostrarComponente(String placa) {

        try {
            BeanRegistroComponente miComponente = null;

            String mostrarComponente = "Select * from componentes where placa = '" + placa + "';";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(mostrarComponente);

            if (rs.next()) {
                miComponente = new BeanRegistroComponente(
                        rs.getString("tipo"),
                        rs.getString("placa"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getString("color"));

                return miComponente;

            }
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public boolean actualizarComponente(BeanRegistroComponente miComponente) {

        try {
            String tipo = miComponente.getTipo();
            String placa = miComponente.getPlaca();
            String marca = miComponente.getMarca();
            String modelo = miComponente.getModelo();
            String color = miComponente.getColor();

            String actualizarComponente = "update componentes set placa = '" + placa + "',"
                    + "tipo = '" + tipo + "', marca = '" + marca + "',"
                    + "modelo = '" + modelo + "', color = '" + color + "'"
                    + "where placa = '" + placa + "';";
            Statement st = cn.createStatement();
            st.executeUpdate(actualizarComponente);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public boolean eliminarComponente(String placa) {

        try {
            String eliminarComponente = "delete from componentes where placa = '" + placa + "';";
            Statement st = cn.createStatement();
            st.executeUpdate(eliminarComponente);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public ResultSet listarPrestamos(int pg, int numreg) {
        try {
            ResultSet rs = null;

            String prestmos = "select * from prestamo_equipos order by id limit " + pg + " , " + numreg + ";";

            Statement st = cn.createStatement();
            rs = st.executeQuery(prestmos);

            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public boolean eliminarPrestamo(int id) {

        try {
            String eliminarprestamo = "delete from prestamo_equipos where id = " + id + ";";
            Statement st = cn.createStatement();
            st.executeUpdate(eliminarprestamo);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public ResultSet listarPrestamoComponentes(int pg, int numreg) {
        try {
            ResultSet rs = null;

            String mostrar = "select * from prestamo_componentes order by id limit " + pg + " , " + numreg + ";";
            Statement st = cn.createStatement();
            rs = st.executeQuery(mostrar);
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public boolean eliminarprestamoComponente(int id) {

        try {
            String query = "delete from prestamo_componentes where id = " + id + ";";
            Statement st = cn.createStatement();
            st.executeUpdate(query);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public ResultSet listarReservas(String documento, int pg, int numreg) {
        try {
            String query = "select * from reserva_equipos where documento='" + documento + "' order by id limit " + pg + " , " + numreg + " ";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public ResultSet listarReservasTodos(int pg, int numreg) {
        try {
            String query = "select * from reserva_equipos order by id limit " + pg + " , " + numreg + "";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public boolean eliminarReservaEquipos(int id) {

        try {
            String query = "delete from reserva_equipos where id = " + id + ";";
            Statement st = cn.createStatement();
            st.executeUpdate(query);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public BeanReservaEquipo mostrarReservasEquipo(String id) {

        try {
            BeanReservaEquipo miEquipo = null;

            String consultarEquipo = "Select * from reserva_equipos where id = '" + id + "';";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(consultarEquipo);

            if (rs.next()) {
                miEquipo = new BeanReservaEquipo(
                        rs.getString("documento"),
                        rs.getString("placa"),
                        rs.getString("fecha_inicio"),
                        rs.getString("fecha_fin"),
                        rs.getString("observaciones"),
                        rs.getString("respuesta"));

                return miEquipo;

            }
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public boolean actualizarReservaEquipos(BeanReservaEquipo2 equipo) {

        try {
            String id = equipo.getId();
            String documento = equipo.getDocumento();
            String placa = equipo.getPlaca();
            String fecha_inicio = equipo.getFecha_inicio();
            String fecha_fin = equipo.getFecha_fin();
            String observaciones = equipo.getObservaciones();
            String respuesta = equipo.getRespuesta();

            String actualizarComponente = "update reserva_equipos set respuesta='" + respuesta + "' where id='" + id + "' ";
            Statement st = cn.createStatement();
            st.executeUpdate(actualizarComponente);
            System.out.println(actualizarComponente);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }

    public boolean registrarReservaComponente(BeanReservaComponente miReserva) {

        try {

            String documento=miReserva.getDocumento();
            String tipo=miReserva.getTipo();
            String placa="pendiente";
            String fecha_inicio=miReserva.getFecha_inicio();
            String fecha_fin=miReserva.getFecha_inicio();
            String observacion=miReserva.getObservacion();
            String respuesta="pendiente respuesta";

            String update = "insert into reserva_componentes values('"+0+"','"+documento+"','"+tipo+"','"+placa+"','"+fecha_inicio+"','"+fecha_fin+"','"+observacion+"','"+respuesta+"');";
            Statement st = cn.createStatement();
            st.executeUpdate(update);
            System.out.println(update);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }
    
    
    public ResultSet listarReservasComponentes(String documento, int pg, int numreg) {
        try {
            String query = "select * from reserva_componentes where documento='" + documento + "' order by id limit " + pg + " , " + numreg + " ";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }
    
    public boolean eliminarReservaComponente(String id) {

        try {
            String eliminar = "Delete from reserva_componentes where id='" + id + "'";
            Statement st = cn.createStatement();
            st.executeUpdate(eliminar);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean eliminarReservaEquipo(String id) {

        try {
            String eliminar = "Delete from reserva_equipos where id='" + id + "'";
            Statement st = cn.createStatement();
            st.executeUpdate(eliminar);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    
    public ResultSet listarReservaComponentes(int pg, int numreg) {
        ResultSet rs = null;
        try {
            String listar = "Select * from reserva_componentes order by id limit " + pg + " , " + numreg + "; ";
            Statement st = cn.createStatement();
            rs = st.executeQuery(listar);

        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;

    }

    public BeanReservaComponente mostrarReservaComponentes(String id) {

        try {
            BeanReservaComponente miEquipo = null;

            String consultarEquipo = "Select * from reserva_componentes where id = '" + id + "';";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(consultarEquipo);

            if (rs.next()) {
                miEquipo = new BeanReservaComponente(
                        rs.getString("documento"),
                        rs.getString("tipo"),
                        rs.getString("placa"),
                        rs.getString("fecha_inicio"),
                        rs.getString("fecha_fin"),
                        rs.getString("observacion"),
                        rs.getString("respuesta"));

                return miEquipo;

            }
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }
    
    
    public boolean actualizarReservaComponente(BeanReservaComponente2 equipo) {

        try {
            String id = equipo.getId();
            String documento = equipo.getDocumento();
            String tipo = equipo.getTipo();
            String placa = equipo.getPlaca();
            String fecha_inicio = equipo.getFecha_inicio();
            String fecha_fin = equipo.getFecha_fin();
            String observaciones = equipo.getObservacion();
            String respuesta = equipo.getRespuesta();

            String actualizarComponente = "update reserva_componentes set respuesta='" + respuesta + "', placa='"+placa+"' where id='" + id + "' ";
            Statement st = cn.createStatement();
            st.executeUpdate(actualizarComponente);
            System.out.println(actualizarComponente);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }
    public boolean cambiarContrasena(String contrasena , String documento){
    
        try {
            String sql = "update usuarios set contrasena = "+contrasena+" where documento = '"+documento+"';";
            Statement st = cn.createStatement();
            st.executeUpdate(sql);
            System.out.println(sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    return false;
    }
    
    public int contarFilasusuario(){
    
        try {
            String query = "Select count(*) from usuarios;";
            Statement st  = cn.createStatement();
            ResultSet pos = st.executeQuery(query);
            int cont=0;
            
            while(pos.next()){
                cont=pos.getInt(1);
            }
            
            int posc=cont;
            return posc;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return 0;
    }
    
    public int contarFilasReservaEquiposTodos(){
        try {
            String query = "select count(*) from reserva_equipos";
            Statement st = cn.createStatement();
            ResultSet pso = st.executeQuery(query);
            int cont=0;
            while(pso.next()){
                cont = pso.getInt(1);
            }
            int posicion = cont;
            return posicion;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    return 0;
    
    }
    
    public int contarFilasequipo(){
    
        try {
            String query = "Select count(*) from equipos;";
            Statement st  = cn.createStatement();
            ResultSet pos = st.executeQuery(query);
            int cont=0;
            
            while(pos.next()){
                cont=pos.getInt(1);
            }
            
            int posc=cont;
            return posc;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return 0;
    }
    
    public int contarFilascomponentes(){
    
        try {
            String query = "Select count(*) from componentes;";
            Statement st  = cn.createStatement();
            ResultSet pos = st.executeQuery(query);
            int cont=0;
            
            while(pos.next()){
                cont=pos.getInt(1);
            }
            
            int posc=cont;
            return posc;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return 0;
    }
    
    public int contarFilasprestamoequipos(){
    
        try {
            String query = "Select count(*) from prestamo_equipos;";
            Statement st  = cn.createStatement();
            ResultSet pos = st.executeQuery(query);
            int cont=0;
            
            while(pos.next()){
                cont=pos.getInt(1);
            }
            
            int posc=cont;
            return posc;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return 0;
    }
    
    public boolean insertarNoticias(String nombre, String descripcion, String imagen){
    
        try {
            String query  = "insert into noticias values ('"+0+"','"+nombre+"','"+descripcion+"','"+imagen+"');";
             
            Statement st = cn.createStatement();
            st.executeUpdate(query);
            System.out.println(query);
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    
    
    
    
    }
    
    public ResultSet MostrarNoticias(){
        try {
            String mostrar = "select * from noticias;";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(mostrar);
            return rs;
            
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean eliminarNoticia(String id){
    
        try {
            String eliminarnoticia = "Delete from noticias where id = '"+id+"';";
            Statement st = cn.createStatement();
            st.executeUpdate(eliminarnoticia);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    
    
    }
    
    
}
