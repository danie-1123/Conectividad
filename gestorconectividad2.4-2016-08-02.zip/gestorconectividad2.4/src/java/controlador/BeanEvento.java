package controlador;

public class BeanEvento {
    
        private String anio;
        private String mes;
        private String dia;
        private String calendario;
        private String hora;
        private String minuto;
        private String duracion;
        private String nombre;
        

    public BeanEvento(String anio, String mes, String dia, String calendario, String hora, String minuto, String duracion, String nombre) {
        this.anio = anio;
        this.mes = mes;
        this.dia = dia;
        this.calendario = calendario;
        this.hora = hora;
        this.minuto = minuto;
        this.duracion = duracion;
        this.nombre = nombre;
    }

    public String getAnio() {
        return anio;
    }

    public void setAnio(String anio) {
        this.anio = anio;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getCalendario() {
        return calendario;
    }

    public void setCalendario(String calendario) {
        this.calendario = calendario;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getMinuto() {
        return minuto;
    }

    public void setMinuto(String minuto) {
        this.minuto = minuto;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
        
        
     
    
}

