/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Andres
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionCalendario {
    
     private String driver;
    private String url;
    private String user;
    private String pass;
    public Connection cn;

    public ConexionCalendario() throws SQLException {

        try {
            driver = "com.mysql.jdbc.Driver";
            url = "jdbc:mysql://localhost/calendario";
            user = "root";
            pass = "";
            
            Class.forName(driver);
            cn = DriverManager.getConnection(url, user, pass);
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionCalendario.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
}
