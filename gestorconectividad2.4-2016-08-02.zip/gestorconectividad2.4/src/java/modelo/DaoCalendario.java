

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Andres
 */

import controlador.BeanEvento;
import controlador.BeanEventoCalendario;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DaoCalendario extends ConexionCalendario{
    
    public DaoCalendario() throws SQLException {
        super();
    }
    
    public void crearEvento(BeanEvento miEvento){
        
        try {
            String anio=miEvento.getAnio();
            String mes=miEvento.getMes();
            String dia=miEvento.getDia();
            String calendario=miEvento.getCalendario();
            String hora=miEvento.getHora();
            String minuto=miEvento.getMinuto();
            String duracion=miEvento.getDuracion();
            String nombre=miEvento.getNombre();
            
            String instruccion="INSERT INTO eventos VALUES ('"+0+"','"+calendario+"','"+nombre+"','"+anio+"','"+mes+"','"+dia+"','"+hora+"','"+minuto+"','"+0+"','"+duracion+"')";
            Statement st=cn.createStatement();
            st.executeUpdate(instruccion);
            
            cn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
       
       
       
       public ResultSet calendarios(){
       
         try {
             String select = "select * from calendarios;";
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery(select);
             return rs;
         } catch (SQLException ex) {
             Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
         }
       return null;
       
       }
    
       public boolean eliminarEvento(int id){
     
        try {
            String delete = "Delete from eventos where idevento = '"+id+"'; ";
            Statement st = cn.createStatement();
            st.executeUpdate(delete);
            System.out.println(delete);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DaoCalendario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        
    
    
    }
       
       public BeanEventoCalendario mostrarInformacionEvento(int id){
       
           BeanEventoCalendario misDatos = null;
        try {
            String query = "Select * from eventos where idevento = '"+id+"'";
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
            if (rs.next()) {
                
                misDatos = new BeanEventoCalendario(
                        rs.getInt("idevento"),
                        rs.getString("calendario"),
                        rs.getString("nombre"),
                        rs.getString("anio"),
                        rs.getString("mes"),
                        rs.getString("dia"),
                        rs.getString("hora"),
                        rs.getString("minuto"),
                        rs.getString("segundo"),
                        rs.getString("duracion"));
                
                return misDatos;
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DaoCalendario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
       }
       
       public boolean actualizarEvento(BeanEventoCalendario miEvento){
       
        try {
            String nombre = miEvento.getNombre();
            String anio = miEvento.getAnio();
            String mes = miEvento.getMes();
            String dia = miEvento.getDia();
            String hora = miEvento.getHora();
            String minuto = miEvento.getMinuto();
            int id = miEvento.getIdevento();
            
            String update = "update eventos set nombre = '"+nombre+"',"
                    + "anio = '"+anio+"', mes = '"+mes+"', dia = '"+dia+"',"
                    + "hora = '"+hora+"', minuto = '"+minuto+"' where idevento = '"+id+"';";
            System.out.println(update);
            Statement st = cn.createStatement();
            st.executeUpdate(update);
            
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DaoCalendario.class.getName()).log(Level.SEVERE, null, ex);
        }
       return false;
       
       }

    
}
