$(document).on("ready",inicio);

function inicio(){
    $("span.help-block").hide();
    $("#btnvalidar").click(validarDocumento);
    $("#btnvalidar").click(validarNombre);
    $("#btnvalidar").click(validarApellido1);
    $("#btnvalidar").click(validarApellido2);
    $("#btnvalidar").click(validarCorreo);
    $("#btnvalidar").click(validarRol);
    $("#btnvalidar").click(validarTelefono);
    $("#btnvalidar").click(validarCelular);
    
    $("#btnvalidar2").click(validarPlaca);
    $("#btnvalidar2").click(validarMarca);
    $("#btnvalidar2").click(validarModelo);
    $("#btnvalidar2").click(validarDisco);
    $("#btnvalidar2").click(validarMemoria);
    $("#btnvalidar2").click(validarProcesador);
    
    $("#btnvalidar3").click(validarTipo);
    $("#btnvalidar3").click(validarPlaca1);
    $("#btnvalidar3").click(validarMarca1);
    $("#btnvalidar3").click(validarModelo1);
    $("#btnvalidar3").click(validarColor);
    
    
    /********************************/
    
    $("#documento").keyup(validarDocumento);
    $("#nombre").keyup(validarNombre);
    $("#primerApellido").keyup(validarApellido1);
    $("#segundoApellido").keyup(validarApellido2);
    $("#correoElectronico").keyup(validarCorreo);
    $("#rol").keyup(validarRol);
    $("#telefono").keyup(validarTelefono);
    $("#celular").keyup(validarCelular);
    
    $("#placa").keyup(validarPlaca);
    $("#marca").keyup(validarMarca);
    $("#modelo").keyup(validarModelo);
    $("#disco").keyup(validarDisco);
    $("#memoria").keyup(validarMemoria);
    $("#procesador").keyup(validarProcesador);
    
    $("#tipo").keyup(validarTipo);
    $("#placa").keyup(validarPlaca1);
    $("#marca").keyup(validarMarca1);
    $("#modelo").keyup(validarModelo1);
    $("#color").keyup(validarColor);
 
}


function validarTipo(){
    var valor= document.getElementById("tipo").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#tipo").parent().attr("class","form-group has-error has-feedback");
        $("#tipo").parent().children("span").text("Seleccione el tipo de componente.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#tipo").parent().attr("class","form-group has-success has-feedback   ");
        $("#tipo").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }
 
 function validarPlaca1(){
    var valor= document.getElementById("placa").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#placa").parent().attr("class","form-group has-error has-feedback");
        $("#placa").parent().children("span").text("Debe ingresar la placa del componente.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#placa").parent().attr("class","form-group has-success has-feedback   ");
        $("#placa").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }
 
 function validarMarca1(){
    var valor= document.getElementById("marca").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#marca").parent().attr("class","form-group has-error has-feedback");
        $("#marca").parent().children("span").text("Debe ingresar la marca del componente.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#marca").parent().attr("class","form-group has-success has-feedback   ");
        $("#marca").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }
 
 function validarModelo1(){
    var valor= document.getElementById("modelo").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#modelo").parent().attr("class","form-group has-error has-feedback");
        $("#modelo").parent().children("span").text("Debe ingresar el modelo del componente.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#modelo").parent().attr("class","form-group has-success has-feedback   ");
        $("#modelo").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }

function validarColor(){
    var valor= document.getElementById("color").value;
    
    
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#color").parent().attr("class","form-group has-error has-feedback");
        $("#color").parent().children("span").text("Debe ingresar el color del componente.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
    else if( !(isNaN(valor)) ) {
        /*$("#iconotexto").remove();*/
        $("#color").parent().attr("class","form-group has-error has-feedback");
        $("#color").parent().children("span").text("No se acepta datos númericos.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
      return false;
} else{
        $("#iconotexto").remove()
        $("#color").parent().attr("class","form-group has-success has-feedback   ");
        $("#color").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
    
  }
   

}










/*****************************************************************/

function validarPlaca(){
    var valor= document.getElementById("placa").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#placa").parent().attr("class","form-group has-error has-feedback");
        $("#placa").parent().children("span").text("Debe ingresar la placa del equipo.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#placa").parent().attr("class","form-group has-success has-feedback   ");
        $("#placa").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }

function validarMarca(){
    var valor= document.getElementById("marca").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#marca").parent().attr("class","form-group has-error has-feedback");
        $("#marca").parent().children("span").text("Debe ingresar la marca del equipo.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#marca").parent().attr("class","form-group has-success has-feedback   ");
        $("#marca").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }

function validarModelo(){
    var valor= document.getElementById("modelo").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#modelo").parent().attr("class","form-group has-error has-feedback");
        $("#modelo").parent().children("span").text("Debe ingresar el modelo del equipo.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#modelo").parent().attr("class","form-group has-success has-feedback   ");
        $("#modelo").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }
 
 function validarDisco(){
    var valor= document.getElementById("disco").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#disco").parent().attr("class","form-group has-error has-feedback");
        $("#disco").parent().children("span").text("Debe ingresar la capacidad de disco del equipo.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#disco").parent().attr("class","form-group has-success has-feedback   ");
        $("#disco").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }
 
 function validarMemoria(){
    var valor= document.getElementById("memoria").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#memoria").parent().attr("class","form-group has-error has-feedback");
        $("#memoria").parent().children("span").text("Debe ingresar la memoria ram del equipo.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#memoria").parent().attr("class","form-group has-success has-feedback   ");
        $("#memoria").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }
 
 function validarProcesador(){
    var valor= document.getElementById("procesador").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#procesador").parent().attr("class","form-group has-error has-feedback");
        $("#procesador").parent().children("span").text("Debe ingresar el tipo de procesador del equipo.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
     else{
        $("#iconotexto").remove();
        $("#procesador").parent().attr("class","form-group has-success has-feedback   ");
        $("#procesador").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
  }
 }












function validarDocumento(){
    var valor= document.getElementById("documento").value;
    
    
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#documento").parent().attr("class","form-group has-error has-feedback");
        $("#documento").parent().children("span").text("Debe ingresar un documento.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
    else if( isNaN(valor) ) {
        /*$("#iconotexto").remove();*/
        $("#documento").parent().attr("class","form-group has-error has-feedback");
        $("#documento").parent().children("span").text("Debe ingresar datos numéricos.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
      return false;
} else{
        $("#iconotexto").remove()
        $("#documento").parent().attr("class","form-group has-success has-feedback   ");
        $("#documento").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
    
  }
   

}

function validarNombre(){
    var valor1= document.getElementById("nombre").value;
    
    
    if( valor1 == null || valor1.length == 0 || /^\s+$/.test(valor1) ) {
        /*$("#iconotexto").remove();*/
        $("#nombre").parent().attr("class","form-group has-error has-feedback");
        $("#nombre").parent().children("span").text("Debe ingresar el nombre.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
    else if( !(isNaN(valor1)) ) {
        /*$("#iconotexto").remove();*/
        $("#nombre").parent().attr("class","form-group has-error has-feedback");
        $("#nombre").parent().children("span").text("No se admiten números.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
      return false;
} else{
        
        $("#nombre").parent().attr("class","form-group has-success has-feedback   ");
        $("#nombre").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
    
  }
   

}

function validarApellido1(){
    var valor2= document.getElementById("primerApellido").value;
    
    
    if( valor2 == null || valor2.length == 0 || /^\s+$/.test(valor2) ) {
        /*$("#iconotexto").remove();*/
        $("#primerApellido").parent().attr("class","form-group has-error has-feedback");
        $("#primerApellido").parent().children("span").text("Debe ingresar el apellido.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
    else if( !(isNaN(valor2)) ) {
        /*$("#iconotexto").remove();*/
        $("#primerApellido").parent().attr("class","form-group has-error has-feedback");
        $("#primerApellido").parent().children("span").text("No se admiten números.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
      return false;
} else{
        
        $("#primerApellido").parent().attr("class","form-group has-success has-feedback   ");
        $("#primerApellido").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
     }
   
}

function validarApellido2(){
    var valor2= document.getElementById("segundoApellido").value;
    
    
    if( valor2 == null || valor2.length == 0 || /^\s+$/.test(valor2) ) {
        /*$("#iconotexto").remove();*/
        $("#segundoApellido").parent().attr("class","form-group has-error has-feedback");
        $("#segundoApellido").parent().children("span").text("Debe ingresar el apellido.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
    else if( !(isNaN(valor2)) ) {
        /*$("#iconotexto").remove();*/
        $("#segundoApellido").parent().attr("class","form-group has-error has-feedback");
        $("#segundoApellido").parent().children("span").text("No se admiten números.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
      return false;
} else{
        
        $("#segundoApellido").parent().attr("class","form-group has-success has-feedback   ");
        $("#segundoApellido").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
      }
   
}

function validarCorreo(){
    var valor2= document.getElementById("correoElectronico").value;
    
    
    if( valor2 == null || valor2.length == 0 || /^\s+$/.test(valor2) ) {
        /*$("#iconotexto").remove();*/
        $("#correoElectronico").parent().attr("class","form-group has-error has-feedback");
        $("#correoElectronico").parent().children("span").text("Debe ingresar su cuenta de correo electrónico.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
    else  if( !(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(valor2)) ) {
        $("#correoElectronico").parent().attr("class","form-group has-error has-feedback");
        $("#correoElectronico").parent().children("span").text("Ingrese un formato de correo válido.").show();
        return false;
        }
    else{
        
        $("#correoElectronico").parent().attr("class","form-group has-success has-feedback   ");
        $("#correoElectronico").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
      }
   
}

function validarRol(){
    var valor2= document.getElementById("rol").value;
    
    
    if( valor2 == null || valor2.length == 0 || /^\s+$/.test(valor2) ) {
        /*$("#iconotexto").remove();*/
        $("#rol").parent().attr("class","form-group has-error has-feedback");
        $("#rol").parent().children("span").text("Seleccione un rol.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
    else  if( !(isNaN(valor2)) ) {
        /*$("#iconotexto").remove();*/
        $("#primerApellido").parent().attr("class","form-group has-error has-feedback");
        $("#primerApellido").parent().children("span").text("No se admiten números.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
      return false;
        }
    else{
        
        $("#rol").parent().attr("class","form-group has-success has-feedback   ");
        $("#rol").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
      }
   
}

function validarTelefono(){
    var valor2= document.getElementById("telefono").value;
    
    
    if( valor2 == null || valor2.length == 0 || /^\s+$/.test(valor2) ) {
        /*$("#iconotexto").remove();*/
        $("#telefono").parent().attr("class","form-group has-error has-feedback");
        $("#telefono").parent().children("span").text("Debe ingresar un número de teléfono.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
    else  if( !(/^\d{7}$/.test(valor2))  ) {
        $("#telefono").parent().attr("class","form-group has-error has-feedback");
        $("#telefono").parent().children("span").text("El número de teléfono tiene 7 dígitos.").show();
        return false;
        }
    else{
        
        $("#telefono").parent().attr("class","form-group has-success has-feedback   ");
        $("#telefono").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
      }
   
}

function validarCelular(){
    var valor2= document.getElementById("celular").value;
    
    
    if( valor2 == null || valor2.length == 0 || /^\s+$/.test(valor2) ) {
        /*$("#iconotexto").remove();*/
        $("#celular").parent().attr("class","form-group has-error has-feedback");
        $("#celular").parent().children("span").text("Debe ingresar un número de celular.").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-remove  form-control-feedback'></span>");*/
        return false;
    }
    else  if( !(/^\d{10}$/.test(valor2))  ) {
        $("#celular").parent().attr("class","form-group has-error has-feedback");
        $("#celular").parent().children("span").text("El número de celular tiene 10 dígitos.").show();
        return false;
        }
    else{
        
        $("#celular").parent().attr("class","form-group has-success has-feedback   ");
        $("#celular").parent().children("span").text("✔").show();
        /*$("#documento").parent().append("<span id='iconotexto' class='glyphicon glyphicon-ok form-control-feedback'></span>");*/
      }
   
}


 