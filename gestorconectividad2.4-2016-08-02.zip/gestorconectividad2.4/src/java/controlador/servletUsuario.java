/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.Dao;

/**
 *
 * @author admin
 */
@WebServlet(name = "servletUsuario", urlPatterns = {"/servletUsuario"})
public class servletUsuario extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        boolean registrar = false;
        boolean registrar2 = false;
        boolean ingresar = false;

        if (request.getParameter("registrar") != null) {
            registrar = true;
        }

        if (request.getParameter("registrar2") != null) {
            registrar2 = true;
        }

        if (request.getParameter("ingresar") != null) {
            ingresar = true;
        }

        if (registrar) {
            try {

                String documento = request.getParameter("documento");
                String nombre = request.getParameter("nombre");
                String primerApellido = request.getParameter("primerApellido");
                String segundoApellido = request.getParameter("segundoApellido");
                String correo = request.getParameter("correoElectronico");
                String rol = request.getParameter("rol");
                String telefono = request.getParameter("telefono");
                String celular = request.getParameter("celular");
                String codigo = GeneradorCodigo.getPassword(GeneradorCodigo.minusculas + GeneradorCodigo.mayusculas, 10);

                System.out.println(codigo);

                BeanUsuario miBean = new BeanUsuario(documento, documento, nombre, primerApellido, segundoApellido, correo, rol, telefono, celular, codigo);
                Dao miDao = new Dao();

                if (miDao.registrarUsuario(miBean)) {
                    /*request.setAttribute("mensaje", "Usuario registrado.");*/
                    request.getRequestDispatcher("si_registro.jsp").forward(request, response);
                    System.out.println("registro exitoso");
                } else {
                    /*request.setAttribute("mensaje", "Error en el registro.");*/
                    request.getRequestDispatcher("error.jsp").forward(request, response);
                }

            } catch (SQLException ex) {
                Logger.getLogger(servletUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        /**
         * **************************************************************************************
         */
        if (registrar2) {
            try {

                String documento = request.getParameter("documento");
                String nombre = request.getParameter("nombre");
                String primerApellido = request.getParameter("primerApellido");
                String segundoApellido = request.getParameter("segundoApellido");
                String correo = request.getParameter("correoElectronico");
                String rol = request.getParameter("rol");
                String telefono = request.getParameter("telefono");
                String celular = request.getParameter("celular");
                String codigo = GeneradorCodigo.getPassword(GeneradorCodigo.minusculas + GeneradorCodigo.mayusculas, 10);

                System.out.println(codigo);

                BeanUsuario miBean = new BeanUsuario(documento, documento, nombre, primerApellido, segundoApellido, correo, rol, telefono, celular, codigo);
                Dao miDao = new Dao();

                if (miDao.registrarUsuario(miBean)) {
                    String mensaje = "Se registró el usuario con exito.";
                    request.setAttribute("mensaje", mensaje);
                    request.getRequestDispatcher("1_RegistrarUsuario.jsp").forward(request, response);

                } else {
                    String mensaje="No se registró el usuario, debe validar si ya existe en el sistema.";
                    request.setAttribute("mensaje", mensaje);
                    request.getRequestDispatcher("1_RegistrarUsuario.jsp").forward(request, response);
                    
                }

            } catch (SQLException ex) {
                Logger.getLogger(servletUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        /**
         * *************************************************************************************
         */
        if (ingresar) {
            try {
                String correo = request.getParameter("usuario");
                String contrasena = request.getParameter("contrasena");

                BeanUsuario miBean = new BeanUsuario(contrasena, null, null, null, null, correo, null, null, null, null);
                Dao miDao = new Dao();

                ResultSet rs = miDao.consultarUsuario(miBean);

                if (rs != null) {
                    String rol = rs.getString(8);

                    if (rol.equals("administrador")) {
                        HttpSession sesion = request.getSession();
                        sesion.setAttribute("usuario", rs);
                        /*request.setAttribute("usuario", rs);*/
                        response.sendRedirect("administrador.jsp");
                    }

                    if (rol.equals("auxiliar")) {
                        HttpSession sesion = request.getSession();
                        sesion.setAttribute("usuario", rs);
                        /*request.setAttribute("usuario", rs);*/
                        response.sendRedirect("auxiliar.jsp");
                        
                    }

                    if (rol.equals("aprendiz")) {
                        HttpSession sesion = request.getSession();
                        sesion.setAttribute("usuario", rs);
                        /*request.setAttribute("usuario", rs);*/
                        response.sendRedirect("aprendiz.jsp");
                    }
                    
                    if (rol.equals("instructor") || rol.equals("administrativo")) {
                        HttpSession sesion = request.getSession();
                        sesion.setAttribute("usuario", rs);
                        /*request.setAttribute("usuario", rs);*/
                        response.sendRedirect("personalcentro.jsp");
                    }

                } else {
                    /*request.setAttribute("mensaje", "Usuario no autorizado.");*/
                    request.getRequestDispatcher("errorautenticacion.jsp").forward(request, response);
                }

            } catch (SQLException ex) {
                Logger.getLogger(servletUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet servletUsuario</title>");            
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Servlet servletUsuario at " + request.getContextPath() + "</h1>");
//            out.println("</body>");
//            out.println("</html>");
//        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
