$('.carousel').carousel({
	interval:7000,
})
