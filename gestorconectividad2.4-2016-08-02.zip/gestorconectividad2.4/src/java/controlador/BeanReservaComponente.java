
package controlador;

public class BeanReservaComponente {
    
    private String documento;
    private String tipo;
    private String placa;
    private String fecha_inicio;
    private String fecha_fin;
    private String observacion;
    private String respuesta;

    public BeanReservaComponente(String documento, String tipo, String placa, String fecha_inicio, String fecha_fin, String observacion, String respuesta) {
        this.documento = documento;
        this.tipo = tipo;
        this.placa = placa;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
        this.observacion = observacion;
        this.respuesta = respuesta;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public String getFecha_fin() {
        return fecha_fin;
    }

    public void setFecha_fin(String fecha_fin) {
        this.fecha_fin = fecha_fin;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }
    
    
}
